export const environment = {
  production: true,
  api:  'https://raasleela-api.mycodelibraries.com/api'

  // firebase: {
  //   apiKey: "Your Api Key",
  //   authDomain: "Your Auth Domain",
  //   databaseURL: "Your Database Url",
  //   projectId: "Your Project Id",
  //   storageBucket: "Your StorageBucket url",
  //   messagingSenderId: "Your Sender Id"
  // }
};
