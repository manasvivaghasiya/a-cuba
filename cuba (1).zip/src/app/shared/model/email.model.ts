export interface Email {
	id: number
	image: any
	name: string
	email: string
	date: string
	cc: string
	type: string
	text: any
	favourite: boolean
}